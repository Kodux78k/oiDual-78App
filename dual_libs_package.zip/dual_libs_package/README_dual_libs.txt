DUAL_INFODOSE - package of minimal service worker and stub libs
--------------------------------------------------------------
Files included (place in your project root or adapt paths):
- sw.js
  - Minimal, neutral Service Worker.
  - Installs and activates, does a simple network-first fetch with cache fallback.
  - Place at project root (same directory as index.html) so it controls scope '/'.
  - To activate immediately from page, you can postMessage({type:'SW_SKIP_WAITING'}) to the service worker.

- libs/particles.min.js
  - Minimal particles stub providing particlesJS(containerId, config).
  - Lightweight animation; suitable for offline/testing.
  - In production replace with official particles.js (vincentGarreau/particles.js).

- libs/html2canvas.min.js
  - Stub implementation of html2canvas(element, options) that returns a simple canvas.
  - Good for local testing and to keep existing code paths working.
  - For real DOM->canvas rendering, replace with official html2canvas library.

- libs/lucide.min.js
  - Small shim that implements lucide.createIcons() no-op + fills [data-lucide] placeholders.
  - Replace with official lucide-icons script for full icon set.

Recommended production upgrade (download real libs and overwrite files in ./libs/):
- particles.js (official) => particles.min.js
- html2canvas (official) => html2canvas.min.js
- lucide (official) => lucide.min.js

Notes about your app:
- particles.js uses a canvas under the #particles-js container — the stub will create a canvas element there.
- html2canvas is used when exporting PNGs (activation download). The stub creates a blank canvas; replace for faithful PNGs.
- Your sync patch already links active keys to localStorage (di_apiKey) when you call setActiveKey(...). Keep using STATE.keys.active to manage per-key tokens.
- If you want, I can also generate a "production-ready" sw.js (precaching specific assets) — tell me which files to precache.

How to use:
1) Put the 'dual_libs_package.zip' content in your project root.
2) Ensure your index.html references ./libs/particles.min.js, ./libs/html2canvas.min.js and ./libs/lucide.min.js as in the loader.
3) Keep sw.js at root and the service worker registration in your page will register it.

Done by ChatGPT — If you want, I can also:
- Create a production sw.js that precaches index.html, css and core assets.
- Replace the html2canvas stub with a more complete open-source bundling (but I can't download it automatically here; I can provide exact filenames to fetch).
